


import numpy as np
import pandas as pd
import sys
from collections import defaultdict


class NaiveBayes:
    def __init__(self,train):
        self.train_df = self.preprocess(train)
        self.train_labels = self.train_df['Class'].unique()
        self.n_rows = self.train_df['Class'].count()
        self.train()
        
    def preprocess(self,filename):
        parsed_lines = []
        with open(filename) as f:
            for line in f.readlines():
                line_data = {}
                split_line = line.split()

                line_data[0] = split_line[0]

                for atr in split_line[1:]:
                    split_atr = list(atr)

                    line_data[int(split_atr[0])] = int(split_atr[2])

                parsed_lines.append(line_data)

        df = pd.DataFrame(parsed_lines)
        df.fillna(0, inplace=True)
        df.columns = ['Atr ' + str(col) for col in df.columns]
        df.rename(columns={df.columns[0]:'Class'}, inplace=True)
        return df
        
    def calculatePriors(self,df):
        n_rows = df['Class'].count()
        
        return { c: df['Class'][df['Class'] == c].count()/n_rows for c in df['Class'].unique() }
    
    def calculateLikelihoods(self):
        atr_vals_by_class = defaultdict(lambda: defaultdict(list))

        for index, row in self.train_df.iterrows():
            cls = row['Class']

            for atr in row.index[1:]:
                atr_vals_by_class[cls][atr].append(row[atr])        

        atr_liklihoods_by_class = defaultdict(lambda:defaultdict(lambda: defaultdict(lambda:0)))

        for cls in self.train_df['Class'].unique():
            for atr in self.train_df.columns[1:]:
                n = len(atr_vals_by_class[cls][atr])

                atr_liklihoods_by_class[cls][atr] = {unique_val: atr_vals_by_class[cls][atr].count(unique_val) / n for unique_val in set(atr_vals_by_class[cls][atr])}
                
        return atr_vals_by_class, atr_liklihoods_by_class

        
        
    def train(self):
        self.train_priors = self.calculatePriors(self.train_df)
        self.train_vals, self.train_likelihoods = self.calculateLikelihoods()
        
    def test(self,dataset):
        test_df = self.preprocess(dataset)
        self.test_df = test_df
        
        classified = {}
        
        priors = self.train_priors
        
        # for each test case
        
        for index, row in test_df.iterrows():
            posterior_numerators = {}
            cls = row['Class']
            
            # calculate posterior numerator of each possible classifcation
            # ignore divisor since we dont need full probability for simple classification 
            
            for c in self.train_labels:
                # Initialize with prior which will be multiplied by likelihood of each attribute
                posterior_numerator =  priors[c]
                
                for atr in row.index[1:]:
                    val = row[atr]
                    
                    posterior_numerator *= self.train_likelihoods[c][atr].get(val,0)
        
                posterior_numerators[c] = posterior_numerator

            classified[index] = max(posterior_numerators, key=posterior_numerators.get)
            
        self.accuracyTest(classified)
    
    def accuracyTest(self,results):
        output = defaultdict(lambda:0)
        
        for index, row in self.test_df.iterrows():
            if row["Class"] == "+1" and results[index] == "+1":
                output["P"] += 1
            elif row["Class"] == "+1" and results[index] == "-1":
                output["FN"] += 1
            elif row["Class"] == "-1" and results[index] == "+1":
                output["FP"] += 1
            elif row["Class"] == "-1" and results[index] == "-1":
                output["N"] += 1
            else:
                print("Error")
        

        print(output['P'],output['FN'],output['FP'],output['N'])
    



def main():
    nb = NaiveBayes(sys.argv[1])
    nb.test(sys.argv[1])
    nb.test(sys.argv[2])


if __name__ == "__main__":
    main()
